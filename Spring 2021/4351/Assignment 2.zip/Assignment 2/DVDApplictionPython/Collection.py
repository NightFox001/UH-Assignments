class Collection:
    def __init__(self):
        self.MAX_NUM_DVDS = 100
        self.DVDs = []
        self.numOfDVDs = numOfDVDs

        def addDVD(category, price, time, title, year):
            pass
        
        def removeDVD(title):
            pass
        
        def editDVD(category, price, time, title, year):
            pass

        def displayByCat():
            pass

        def displayByYear():
            pass

        def restoreCollection():
            pass

        def saveCollection():
            pass

