class View
    def showStuff():
        pass