class MovieCompanySystem
    def __init__(self):
    view = View()
    controller = Controller()