class Controller
    def __init__(self):
        self.collection = Collection

        def UCAddDVD(category, price, time, title, year):
            pass
        
        def UCRemoveDVD(title):
            pass
        
        def UCEditDVD(category, price, time, title, year):
            pass

        def UCDisplayByCat():
            pass

        def UCDisplayByYear():
            pass

        def UCRestoreCollection():
            pass

        def UCSaveCollection():
            pass

