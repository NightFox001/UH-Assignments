class DVD:
    def __init__(self, title, category, price, year, time):
        self.title = title
        self.category = category
        self.price = price
        self.year = year
        self.time = time

