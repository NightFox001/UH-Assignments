﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDApplictionCSharp
{
    public class View
    {
        public void showGUI()
        {
            throw new System.NotImplementedException();
        }
    }
}