﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDApplictionCSharp
{
    public class DVD
    {
        private string title
        {
            get => default;
            set
            {
            }
        }

        private string category
        {
            get => default;
            set
            {
            }
        }

        private string time
        {
            get => default;
            set
            {
            }
        }

        private int year
        {
            get => default;
            set
            {
            }
        }

        private float price
        {
            get => default;
            set
            {
            }
        }

        public void setTitle(string title)
        {
            throw new System.NotImplementedException();
        }

        public void setCategory(string category)
        {
            throw new System.NotImplementedException();
        }

        public void setTime(string time)
        {
            throw new System.NotImplementedException();
        }

        public void setPrice(float price)
        {
            throw new System.NotImplementedException();
        }

        public void setYear(int year)
        {
            throw new System.NotImplementedException();
        }
    }
}