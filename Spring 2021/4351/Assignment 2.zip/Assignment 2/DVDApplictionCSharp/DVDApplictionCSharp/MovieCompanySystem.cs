﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDApplictionCSharp
{
    public class MovieCompanySystem
    {
        public Controller controller
        {
            get => default;
            set
            {
            }
        }

        public View view
        {
            get => default;
            set
            {
            }
        }

        public string category
        {
            get => default;
            set
            {
            }
        }

        public float price
        {
            get => default;
            set
            {
            }
        }

        public string time
        {
            get => default;
            set
            {
            }
        }

        public string title
        {
            get => default;
            set
            {
            }
        }

        public int year
        {
            get => default;
            set
            {
            }
        }

        public int dvdCollectionIndex
        {
            get => default;
            set
            {
            }
        }

        public int ChosenDVD
        {
            get => default;
            set
            {
            }
        }

        public static void Main()
        {
            throw new System.NotImplementedException();
        }
    }
}