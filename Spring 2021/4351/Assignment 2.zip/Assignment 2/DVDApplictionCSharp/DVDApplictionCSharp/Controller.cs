﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDApplictionCSharp
{
    public class Controller
    {
        private Collection collection
        {
            get => default;
            set
            {
            }
        }

        public void UCRestoreCollection(Collection collection)
        {
            throw new System.NotImplementedException();
        }

        public void UCAddDVD(string category, float price, string time, string title, int year)
        {
            throw new System.NotImplementedException();
        }

        public Collection UCSaveCollection()
        {
            throw new System.NotImplementedException();
        }

        public void UCRemoveDVD()
        {
            throw new System.NotImplementedException();
        }

        public void UCEditDVD()
        {
            throw new System.NotImplementedException();
        }

        public void UCDisplayByCategory()
        {
            throw new System.NotImplementedException();
        }

        public void UCDisplayByYear()
        {
            throw new System.NotImplementedException();
        }
    }
}